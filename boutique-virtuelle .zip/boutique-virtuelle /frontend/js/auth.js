// Gestion de l'authentification côté client
document.addEventListener('DOMContentLoaded', () => {
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    
    const loginLink = document.getElementById('login-link');
    const logoutBtn = document.getElementById('logout-btn');
    const coinsDisplay = document.getElementById('coins-display');
    const adminLink = document.querySelector('a[href="/admin.html"]');

    if (token && userStr) {
        // Utilisateur connecté
        const user = JSON.parse(userStr);
        if (loginLink) loginLink.style.display = 'none';
        if (logoutBtn) logoutBtn.style.display = 'inline-block';
        if (coinsDisplay) coinsDisplay.textContent = `🪙 ${user.coins || 0}`;
        
        // Afficher le lien admin si l'utilisateur est admin
        if (adminLink && user.is_admin) {
            adminLink.style.display = 'inline-block';
        } else if (adminLink) {
            adminLink.style.display = 'none';
        }
        
        logoutBtn.addEventListener('click', () => {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
            window.location.href = '/';
        });
    } else {
        // Utilisateur non connecté
        if (loginLink) loginLink.style.display = 'inline-block';
        if (logoutBtn) logoutBtn.style.display = 'none';
        if (coinsDisplay) coinsDisplay.textContent = '🪙 0';
        if (adminLink) adminLink.style.display = 'none';
    }
});

// Fonction pour mettre à jour l'affichage des pièces
function updateCoinsDisplay(newBalance) {
    const coinsDisplay = document.getElementById('coins-display');
    if (coinsDisplay) {
        coinsDisplay.textContent = `🪙 ${newBalance}`;
        
        // Mettre à jour le localStorage
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        user.coins = newBalance;
        localStorage.setItem('user', JSON.stringify(user));
    }
}

// Fonction pour afficher une notification
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}