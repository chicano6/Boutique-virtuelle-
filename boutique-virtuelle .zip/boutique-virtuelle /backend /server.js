const express = require('express');
const path = require('path');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { pool, initDB } = require('./database');

require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'votre_secret_jwt_tres_long_et_securise';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ========== MIDDLEWARE D'AUTHENTIFICATION ==========
const authenticate = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) return res.status(401).json({ error: 'Non authentifié' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await pool.query('SELECT id, username, email, coins, referral_code, is_admin FROM users WHERE id = $1', [decoded.userId]);
    if (user.rows.length === 0) return res.status(401).json({ error: 'Utilisateur non trouvé' });
    
    req.user = user.rows[0];
    next();
  } catch (error) {
    return res.status(401).json({ error: 'Token invalide' });
  }
};

// ========== MIDDLEWARE ADMIN ==========
const isAdmin = async (req, res, next) => {
  try {
    if (!req.user.is_admin) {
      return res.status(403).json({ error: 'Accès non autorisé' });
    }
    next();
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
};

// ========== ROUTES D'AUTHENTIFICATION ==========
app.post('/api/register', async (req, res) => {
  const { username, email, password, referralCode } = req.body;
  
  try {
    const existingUser = await pool.query('SELECT id FROM users WHERE email = $1 OR username = $2', [email, username]);
    if (existingUser.rows.length > 0) {
      return res.status(400).json({ error: 'Email ou nom d\'utilisateur déjà utilisé' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newReferralCode = uuidv4().substring(0, 8);
    
    let referredBy = null;
    if (referralCode) {
      const referrer = await pool.query('SELECT id FROM users WHERE referral_code = $1', [referralCode]);
      if (referrer.rows.length > 0) {
        referredBy = referrer.rows[0].id;
      }
    }

    const result = await pool.query(
      'INSERT INTO users (username, email, password_hash, referral_code, referred_by, coins) VALUES ($1, $2, $3, $4, $5, 10) RETURNING id, username, email, coins, referral_code, is_admin',
      [username, email, hashedPassword, newReferralCode, referredBy]
    );

    const newUser = result.rows[0];

    if (referredBy) {
      await pool.query('UPDATE users SET coins = coins + 20 WHERE id = $1', [referredBy]);
      await pool.query('INSERT INTO referrals (referrer_id, referred_id, coins_awarded) VALUES ($1, $2, 20)', [referredBy, newUser.id]);
      await pool.query('UPDATE users SET coins = coins + 10 WHERE id = $1', [newUser.id]);
    }

    const token = jwt.sign({ userId: newUser.id }, JWT_SECRET, { expiresIn: '7d' });

    res.json({ token, user: newUser });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  
  try {
    const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);
    if (!validPassword) {
      return res.status(401).json({ error: 'Email ou mot de passe incorrect' });
    }

    const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
    
    res.json({
      token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        coins: user.coins,
        referral_code: user.referral_code,
        is_admin: user.is_admin
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ========== ROUTES SHOP ==========
app.get('/api/products', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM products ORDER BY price_coins ASC');
    res.json(result.rows);
  } catch (error) {
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/api/purchase/:productId', authenticate, async (req, res) => {
  const productId = parseInt(req.params.productId);
  const userId = req.user.id;

  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');

    const product = await client.query('SELECT * FROM products WHERE id = $1', [productId]);
    if (product.rows.length === 0) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: 'Produit non trouvé' });
    }

    const productData = product.rows[0];
    
    const user = await client.query('SELECT coins FROM users WHERE id = $1 FOR UPDATE', [userId]);
    if (user.rows[0].coins < productData.price_coins) {
      await client.query('ROLLBACK');
      return res.status(400).json({ error: 'Solde insuffisant' });
    }

    await client.query('UPDATE users SET coins = coins - $1 WHERE id = $2', [productData.price_coins, userId]);
    await client.query(
      'INSERT INTO purchases (user_id, product_id, price_paid) VALUES ($1, $2, $3)',
      [userId, productId, productData.price_coins]
    );

    await client.query('COMMIT');

    const updatedUser = await pool.query('SELECT coins FROM users WHERE id = $1', [userId]);

    res.json({
      success: true,
      message: 'Achat réussi',
      download_url: productData.download_url,
      new_balance: updatedUser.rows[0].coins
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    res.status(500).json({ error: 'Erreur lors de l\'achat' });
  } finally {
    client.release();
  }
});

// ========== ROUTES EARN (PUB) ==========
app.post('/api/earn/watch-ad', authenticate, async (req, res) => {
  const userId = req.user.id;
  const coinsEarned = 5;

  const lastWatch = await pool.query(
    'SELECT COUNT(*) FROM ad_watches WHERE user_id = $1 AND watched_at > NOW() - INTERVAL \'1 hour\'',
    [userId]
  );

  if (parseInt(lastWatch.rows[0].count) >= 10) {
    return res.status(429).json({ error: 'Trop de publicités regardées, réessayez plus tard' });
  }

  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');

    await client.query('UPDATE users SET coins = coins + $1 WHERE id = $2', [coinsEarned, userId]);
    await client.query(
      'INSERT INTO ad_watches (user_id, coins_earned) VALUES ($1, $2)',
      [userId, coinsEarned]
    );

    await client.query('COMMIT');

    const updatedUser = await pool.query('SELECT coins FROM users WHERE id = $1', [userId]);

    res.json({
      success: true,
      coins_earned: coinsEarned,
      new_balance: updatedUser.rows[0].coins
    });

  } catch (error) {
    await client.query('ROLLBACK');
    console.error(error);
    res.status(500).json({ error: 'Erreur lors du gain de pièces' });
  } finally {
    client.release();
  }
});

// ========== ROUTES PARRAINAGE ==========
app.get('/api/referral/info', authenticate, async (req, res) => {
  try {
    const referralLink = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/register?ref=${req.user.referral_code}`;
    
    const referrals = await pool.query(
      'SELECT COUNT(*) as count FROM users WHERE referred_by = $1',
      [req.user.id]
    );
    
    const earnings = await pool.query(
      'SELECT SUM(coins_awarded) as total FROM referrals WHERE referrer_id = $1',
      [req.user.id]
    );

    res.json({
      referral_code: req.user.referral_code,
      referral_link: referralLink,
      total_referrals: parseInt(referrals.rows[0].count),
      total_earned: parseInt(earnings.rows[0].total) || 0
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ========== ROUTES DASHBOARD ==========
app.get('/api/dashboard', authenticate, async (req, res) => {
  try {
    const purchases = await pool.query(`
      SELECT p.*, pr.name, pr.description, pr.image_url, pr.download_url
      FROM purchases p
      JOIN products pr ON p.product_id = pr.id
      WHERE p.user_id = $1
      ORDER BY p.purchased_at DESC
    `, [req.user.id]);

    const adHistory = await pool.query(`
      SELECT * FROM ad_watches 
      WHERE user_id = $1 
      ORDER BY watched_at DESC 
      LIMIT 10
    `, [req.user.id]);

    const stats = {
      total_purchases: purchases.rows.length,
      total_spent: purchases.rows.reduce((sum, p) => sum + p.price_paid, 0),
      total_ads_watched: (await pool.query('SELECT COUNT(*) FROM ad_watches WHERE user_id = $1', [req.user.id])).rows[0].count
    };

    res.json({
      user: req.user,
      purchases: purchases.rows,
      ad_history: adHistory.rows,
      stats
    });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// ========== ROUTES ADMINISTRATEUR ==========
app.get('/api/admin/stats', authenticate, isAdmin, async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM products) as total_products,
        (SELECT COUNT(*) FROM purchases) as total_purchases,
        (SELECT SUM(price_paid) FROM purchases) as total_coins_spent,
        (SELECT SUM(coins_earned) FROM ad_watches) as total_coins_earned,
        (SELECT COUNT(*) FROM ad_watches) as total_ads_watched,
        (SELECT COUNT(*) FROM referrals) as total_referrals,
        (SELECT SUM(coins) FROM users) as total_coins_in_circulation
    `);
    
    res.json(stats.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.get('/api/admin/users', authenticate, isAdmin, async (req, res) => {
  try {
    const { search, page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    
    let query = `
      SELECT id, username, email, coins, referral_code, 
             created_at, is_admin,
             (SELECT COUNT(*) FROM purchases WHERE user_id = users.id) as purchase_count,
             (SELECT COUNT(*) FROM ad_watches WHERE user_id = users.id) as ad_count
      FROM users
    `;
    const params = [];
    
    if (search) {
      query += ` WHERE username ILIKE $1 OR email ILIKE $1`;
      params.push(`%${search}%`);
    }
    
    query += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);
    
    const users = await pool.query(query, params);
    
    const countResult = await pool.query('SELECT COUNT(*) FROM users' + (search ? ' WHERE username ILIKE $1 OR email ILIKE $1' : ''), 
      search ? [`%${search}%`] : []);
    
    res.json({
      users: users.rows,
      total: parseInt(countResult.rows[0].count),
      page: parseInt(page),
      totalPages: Math.ceil(parseInt(countResult.rows[0].count) / limit)
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.put('/api/admin/users/:userId', authenticate, isAdmin, async (req, res) => {
  const { userId } = req.params;
  const { coins, is_admin } = req.body;
  
  try {
    await pool.query(
      'UPDATE users SET coins = COALESCE($1, coins), is_admin = COALESCE($2, is_admin) WHERE id = $3',
      [coins, is_admin, userId]
    );
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.get('/api/admin/products', authenticate, isAdmin, async (req, res) => {
  try {
    const products = await pool.query('SELECT * FROM products ORDER BY id DESC');
    res.json(products.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.post('/api/admin/products', authenticate, isAdmin, async (req, res) => {
  const { name, description, price_coins, download_url, image_url, stock } = req.body;
  
  try {
    const result = await pool.query(
      'INSERT INTO products (name, description, price_coins, download_url, image_url, stock) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
      [name, description, price_coins, download_url, image_url, stock || -1]
    );
    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.put('/api/admin/products/:productId', authenticate, isAdmin, async (req, res) => {
  const { productId } = req.params;
  const { name, description, price_coins, download_url, image_url, stock } = req.body;
  
  try {
    await pool.query(
      `UPDATE products SET 
        name = COALESCE($1, name),
        description = COALESCE($2, description),
        price_coins = COALESCE($3, price_coins),
        download_url = COALESCE($4, download_url),
        image_url = COALESCE($5, image_url),
        stock = COALESCE($6, stock)
      WHERE id = $7`,
      [name, description, price_coins, download_url, image_url, stock, productId]
    );
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.delete('/api/admin/products/:productId', authenticate, isAdmin, async (req, res) => {
  const { productId } = req.params;
  
  try {
    await pool.query('DELETE FROM products WHERE id = $1', [productId]);
    res.json({ success: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

app.get('/api/admin/transactions', authenticate, isAdmin, async (req, res) => {
  try {
    const { limit = 50 } = req.query;
    
    const purchases = await pool.query(`
      SELECT p.*, u.username, pr.name as product_name, 'purchase' as type
      FROM purchases p
      JOIN users u ON p.user_id = u.id
      JOIN products pr ON p.product_id = pr.id
      ORDER BY p.purchased_at DESC
      LIMIT $1
    `, [limit]);
    
    const adWatches = await pool.query(`
      SELECT a.*, u.username, 'ad' as type
      FROM ad_watches a
      JOIN users u ON a.user_id = u.id
      ORDER BY a.watched_at DESC
      LIMIT $1
    `, [limit]);
    
    res.json({
      purchases: purchases.rows,
      adWatches: adWatches.rows
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

// Redirection pour les routes SPA
app.get('*', (req, res) => {
  if (!req.path.startsWith('/api')) {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
  }
});

// Initialiser la base de données et démarrer le serveur
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🚀 Serveur démarré sur http://localhost:${PORT}`);
  });
});