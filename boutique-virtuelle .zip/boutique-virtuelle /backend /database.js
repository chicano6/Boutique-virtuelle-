const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Initialisation des tables
const initDB = async () => {
  try {
    // Table des utilisateurs
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        coins INTEGER DEFAULT 10,
        referral_code VARCHAR(20) UNIQUE,
        referred_by INTEGER REFERENCES users(id),
        is_admin BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Table des produits
    await pool.query(`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        price_coins INTEGER NOT NULL,
        download_url TEXT,
        image_url TEXT,
        stock INTEGER DEFAULT -1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Table des achats
    await pool.query(`
      CREATE TABLE IF NOT EXISTS purchases (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        product_id INTEGER REFERENCES products(id),
        price_paid INTEGER NOT NULL,
        purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Table des visionnages de publicités
    await pool.query(`
      CREATE TABLE IF NOT EXISTS ad_watches (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id),
        coins_earned INTEGER NOT NULL,
        watched_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Table des parrainages
    await pool.query(`
      CREATE TABLE IF NOT EXISTS referrals (
        id SERIAL PRIMARY KEY,
        referrer_id INTEGER REFERENCES users(id),
        referred_id INTEGER REFERENCES users(id),
        coins_awarded INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Insérer quelques produits de démonstration
    const products = await pool.query('SELECT COUNT(*) FROM products');
    if (parseInt(products.rows[0].count) === 0) {
      await pool.query(`
        INSERT INTO products (name, description, price_coins, download_url, image_url) VALUES
        ('Guide Ultime', 'Un guide complet pour débuter', 50, '/downloads/guide.pdf', 'https://via.placeholder.com/300x200?text=Guide'),
        ('Template Premium', 'Template HTML/CSS professionnel', 100, '/downloads/template.zip', 'https://via.placeholder.com/300x200?text=Template'),
        ('E-book Exclusif', 'Apprenez les secrets du succès', 75, '/downloads/ebook.pdf', 'https://via.placeholder.com/300x200?text=E-book')
      `);
    }

    console.log('✅ Base de données initialisée');
  } catch (error) {
    console.error('❌ Erreur DB:', error);
  }
};

module.exports = { pool, initDB };